from django.urls import path
from .import views
from django.contrib.auth import views as auth_views
urlpatterns = [
    path('create_post', views.create_post, name='create_post'),
    path('post_list', views.post_list, name='post_list'),
    path('post_detail<int:id>', views.post_detail, name='post_detail'),
    path('', views.dashboard, name='dashboard'),
    path('user_login', views.user_login, name='user_login'),
    path('loginn', views.loginn, name='loginn'),

    path('logout', auth_views.LogoutView.as_view(next_page='/blogadmin/'), name='logout'),
    path("delete_post<int:post_id>", views.delete_post, name="delete_post"),
]
