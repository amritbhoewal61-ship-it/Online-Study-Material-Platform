import os
from django.contrib import admin
from django.core.files.base import ContentFile
from import_export import resources
from import_export.admin import ImportExportModelAdmin
from import_export.formats.base_formats import XLSX
from openpyxl import load_workbook
from .models import Post

class PostResource(resources.ModelResource):
    class Meta:
        model = Post
        fields = ('id', 'title', 'img') 

    def before_import_row(self, row, row_number, **kwargs):
        excel_row_idx = row_number + 1
        
        import_file = kwargs.get('import_file')
        if import_file and hasattr(import_file, 'file'):
            file_stream = import_file.file
        else:
            file_stream = kwargs.get('file_stream')
        
        if file_stream:
            try:
                file_stream.seek(0)
                wb = load_workbook(file_stream)
                ws = wb.active
                
                for image in ws._images:
                    current_img_row = image.anchor._from.row + 1
                    
                    if current_img_row == excel_row_idx:
                        image_data = image._data()
                        image_name = f"post_img_{excel_row_idx}.png"
                        
                        django_file = ContentFile(image_data(), name=image_name)
                        row['img'] = django_file
                        break
                        
            except Exception as e:
                print(f"Error: {e}")


@admin.register(Post)
class PostAdmin(ImportExportModelAdmin):
    resource_class = PostResource
    formats = [XLSX]