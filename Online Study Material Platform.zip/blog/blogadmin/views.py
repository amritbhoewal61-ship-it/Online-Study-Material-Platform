from django.shortcuts import render, redirect,get_object_or_404
from .forms import PostForm
from .models import Post,VisitorCount
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages




from django.shortcuts import render, redirect
from django.contrib import messages
from django.core.files.storage import FileSystemStorage

def create_post(request):
    if request.method == "POST":
        title = request.POST.get("title")
        tags = request.POST.get("tags")
        content = request.POST.get("content")   
        img = request.FILES.get("img")
        content_type= request.POST.get("content_type")


        print("CONTENT:", content)  # Debugging

        post = Post.objects.create(
            title=title,
            tags=tags,
            content=content,
            content_type=content_type,
            img=img
        )
        messages.success(request, "Post created successfully!")
        return redirect("post_list")

    return render(request, "create_post.html")
    
def delete_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    post.delete()
    messages.success(request, "Post deleted successfully!")
    return redirect("post_list")


def post_list(request):
    posts = Post.objects.all().order_by('-upload_date')
    return render(request, 'post_list.html', {'posts': posts})

def post_detail (request,id):
    post=Post.objects.get(id=id)
    p=Post.objects.all().order_by('-id')

    return render(request, 'post.html', {'post': post,'p':p})


def dashboard(request):
    post_count = Post.objects.count()
    visitor = VisitorCount.objects.first()
    v = visitor.count if visitor else 0
    return render(request, 'dashboad.html',{'post_count':post_count,'v':v})

    

def user_login(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect("dashboard")   # redirect to your dashboard/home page
        else:

            return redirect("loginn")  # reload login page with error

    # if GET request, just render the login form
def loginn(request):
    return render(request, 'loginn.html')

