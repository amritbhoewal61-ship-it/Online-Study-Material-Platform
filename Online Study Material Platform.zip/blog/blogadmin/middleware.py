# middleware.py
from .models import VisitorCount

class VisitorCounterMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Only count unique sessions
        if not request.session.get('has_counted'):
            visitor, created = VisitorCount.objects.get_or_create(id=1)
            visitor.count += 1
            visitor.save()
            request.session['has_counted'] = True

        response = self.get_response(request)
        return response


from django.shortcuts import redirect
from django.urls import reverse
from django.conf import settings

class LoginRequiredMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):

        # Admin always allowed
        if request.path.startswith('/admin/'):
            return self.get_response(request)

        # School app always allowed (no login required)
        if request.path.startswith(""):
            return self.get_response(request)

        # Allow static and media files
        if settings.STATIC_URL and request.path.startswith(settings.STATIC_URL):
            return self.get_response(request)
        if settings.MEDIA_URL and request.path.startswith(settings.MEDIA_URL):
            return self.get_response(request)

        # Stdapp protected
        if request.path.startswith('blogadmin/'):
            if not request.user.is_authenticated:
                return redirect('loginn')

        # Allowed public paths
        allowed_paths = [
            reverse('loginn'),
            reverse('user_login'),
            # reverse('login_error'),
            # reverse('home'),
        ]

        if not request.user.is_authenticated and request.path not in allowed_paths:
            return redirect('loginn')

        return self.get_response(request)
