from django.db import models

# Create your models here.
from django.db import models
from django.utils import timezone
from django.db import models
from PIL import Image
from io import BytesIO
from django.core.files.base import ContentFile
import os

class Post(models.Model):
    CONTENT_TYPES = [
        ('worksheet', 'Worksheet'),
        ('paper', 'Paper'),
        ('blog', 'Blog'),
        ('custom', 'Custom'),
        ('posts','posts'),
    ]
    title = models.CharField(max_length=200)
    content = models.TextField()   
    tags = models.TextField(blank=True, null=True)
    img = models.FileField(upload_to='media', blank=True, null=True)
    upload_date = models.DateTimeField(default=timezone.now)
    content_type = models.CharField(max_length=20, choices=CONTENT_TYPES, default='posts')

    def __str__(self):
        return self.title

def save(self, *args, **kwargs):
        if self.img:
            file_extension = os.path.splitext(self.img.name)[1].lower()
            
            if file_extension in ['.jpg', '.jpeg', '.png']:
                img = Image.open(self.img)
                
                if img.format != 'WEBP':
                    output = BytesIO()
                    
                    if img.mode in ("RGBA", "P"):
                        img = img.convert("RGB")
                    
                    img.save(output, format='WEBP', quality=80)
                    output.seek(0)
                    
                    curr_name = os.path.splitext(self.img.name)[0]
                    self.img.save(f"{curr_name}.webp", ContentFile(output.read()), save=False)

        super().save(*args, **kwargs)

# models.py
from django.db import models

class VisitorCount(models.Model):
    count = models.PositiveIntegerField(default=0)

    def __str__(self):
        return f"Visitors: {self.count}"
