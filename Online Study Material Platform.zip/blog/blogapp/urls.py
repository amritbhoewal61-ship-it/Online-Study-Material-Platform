from django.urls import path
from . import views

urlpatterns = [
    path('home', views.home, name='home'),     
    path('', views.home, name='home'),              

    path('post_list_main', views.post_list_main, name='post_list_main'),
    path('post_detail_main<int:id>', views.post_detail_main, name='post_detail_main'),
    path("search_post", views.search_posts, name="search_posts"),
    path('worksheets', views.worksheets, name='worksheets'),

]  


