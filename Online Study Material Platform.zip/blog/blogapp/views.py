from django.shortcuts import render
from blogadmin.models import Post
from django.db.models import Q
import re

def search_posts(request):
    query = request.GET.get("q")
    results = []

    if query:
        # Split on commas or spaces
        keywords = re.split(r"[,\s]+", query.strip())
        q_objects = Q()
        for word in keywords:
            if word:  # skip empty strings
                q_objects |= Q(title__icontains=word) | Q(tags__icontains=word) | Q(content__icontains=word)
        results = Post.objects.filter(q_objects).distinct()

    return render(request, "post_search.html", {"results": results, "query": query})

def home(request):
    posts = Post.objects.all().order_by('-upload_date')[:10]
    return render(request,'home.html',{'posts': posts})
    
def post_list_main(request):
    posts = Post.objects.all().order_by('-upload_date')
    return render(request, 'post_list_main.html', {'posts': posts})

def post_detail_main (request,id):
    post=Post.objects.get(id=id)
    p=Post.objects.all().order_by('-id')
    
    return render(request, 'post_main.html', {'post': post,'p':p})
def worksheets(request):
    posts = Post.objects.filter(content_type='worksheet').order_by('-upload_date')
    return render(request, 'worksheets.html', {'posts': posts})

